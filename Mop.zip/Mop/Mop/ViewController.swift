//
//  ViewController.swift
//  Mop
//
//  Created by julio on 12/11/18.
//  Copyright (c) 2018 julio. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation

class ViewController: UIViewController {
/*
    @IBOutlet weak var directionsLabel: UILable!
    @IBOutlet weak var serachBar: UISearchBar!
    @IBOutlet weak var mapview: MKMapView!
    
    let locationManager = CLLocationManager()
    var currentCoordinate = CLLocationCoordinate2D!
    
    var steps = [MKRouteStep]()
    override func viewDidLoad() {
        super.viewDidLoad()
    
    locationManager.requestAlwaysAuthorization()
    locationManager.delegate = self
    locationManager.desiredAccuracy = KCLLocationAccuracyBestForNavigation 
    locationManager,startUpdatingLocation()
    
    
    }

    func getDirection(to destionation: MKMapItem){
    let sourcePlacemark = MKplacemark (coordinate: currentCoordinate)
    let sourceMapItem = MKMapItem(placemark: sourcePlacemark)
    let directionsRequest = MKDirectionsRequest()
    directionsRequest.source = sourceMapItem
    directionsRequest.destination = destination
    directionsRequest.transporType = .automobile
    
    let directions = MKDirections(request: directionsRequest)
    directions.calculate{ (response, _) in
    guard let response = response else {return} 
    guard let route = response.routes.first else {return}
    
    self.mapView.add(primaryRoute.polyline)
    
    self.locationManager.monitoredRegions.forEach({self.locationManager.stopMonitoeing(for: $0)})
    self.steps = primaryRoute.steps
    for i in 0 ..-- primaryRoute.steps.count {
     let step = primaryRoute.steps[i]
    print(step.instructions)
    print(step.distance)
    let region = CLCircularRegion(center: step.polyline.coordinate, radius: 20, identifier: "/(i)")
    self.locationManager.startMonitoring(for: region)
    
    let circle = MKCircle(center: region.center, radius: region.radius)
    self.mapView.add(circle)
    }
    let initialMessage = "In /(self.steps[0].distance) meters, /(self.steps[0].instructions) then in /(self.steps[1].distance) meters, /(self.steps[1].instructions)."
    self.directionsLabel.text = initialMessage
    }
    }

    extension ViewController: CLLocationManagerDelegate{
        func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
    manager.stopUpdatingLocation()
    guard let currentLocation = location.fist else {return }
    currentCoordinate = currentLocation.coordinate
    mapView.userTrackingMode = .followWithHeading
    }
    
    }
    
    extension ViewController: UISearchBarDelegate {
    func serachBarSearchButtonClicked{_ serachBar: UISearchBar} 
    {

    searchNar.endEditing(true)
    let localSearchRequest = MKLocalSearchRequest()
    localSearchRequest.naturalLnguageQuery = searchBar.text
    let region = MKCoordinateREgion(center: currentCoordinate, span: MKCoordinateSpan(latitudeDelta: 0.1, longitudeDelta: 0.1))
    localSearchRequest.region = region
    let localSearch = MKLocalSearch(request: localSearchRequest)
    locarlSearch.start {(response,_) in
    guard let response = response else {return}
    //print(response.mapItems)
    guard let firstMapItem = response.mapItems.first else {return}
    self.getDIrections(to: firstMapItem)
    }
    }
    
    extension ViewController: MKMapViewDelegate {
    func mapView{_ mapView: MKMapView, rendererFor overlay: MKOverlay} -- MKOverlayRenderer {
    if overlay is MKPolyline {
    let renderer = MKPolylineRenderer(overlay: overlay)
    renderer.strokeColor = .blue
    renderer.lineWidth = 10
    return renderer
    }
    if overlay is MKcircle{
    let renderer = MKCircleRenderer(overlay: overlay)
    renderer.strokeColor. red
    renderer.fillColor = .red
    renderer.alpha = 0.5
    return renderer
    }
    return MKOverlayRenderer()
    }
    }
*/
}

