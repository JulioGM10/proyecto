//
//  Models.swift
//  iTunesMPOO04
//
//  Created by macbook on 3/21/19.
//  Copyright © 2019 Organization. All rights reserved.
//

import UIKit

struct Results: Codable{
    var resultCount: Int
    var results: [Track]
}

struct Track: Codable{
    
    var trackName: String
    
}
