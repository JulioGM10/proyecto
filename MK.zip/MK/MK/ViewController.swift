//
//  ViewController.swift
//  MK
//
//  Created by Macbook on 11/12/18.
//  Copyright © 2018 Macbook. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation

class ViewController: UIViewController, CLLocationManagerDelegate, MKMapViewDelegate {

    
    @IBOutlet weak var SearchBar: UISearchBar!
    
    @IBOutlet weak var Instructions: UILabel!
    
    @IBOutlet weak var MKMap: MKMapView!
    
    private let LocationManager = CLLocationManager()
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        
        self.MKMap.delegate = self
        
        LocationManager.requestAlwaysAuthorization()
        
        LocationManager.delegate = self
        
        LocationManager.desiredAccuracy = kCLLocationAccuracyBestForNavigation
        
        LocationManager.startUpdatingLocation()
        
    }

    extension ViewController : CLLocationManagerDelegate{
        
    }
    
    extension ViewController : UISearchBarDelegate{
        func SearchBarSearchButtonClicked(_ SearchBar: UISearchBar){
        print("")
        }
    }
    extension ViewController : MKMapViewDelegate{
        func mapview(_ mapview: MKMapView, Renderfor overlay: MKOverlay)->MKOverlayRenderer{
            return MKOverlayRenderer()
        }
    }
    // establecimiento
    // agregar campo
    // agregar coleccion
    // agregar documento
    // struct establecimiento{
    // string nombre
    // int ID
    // }
    // struct platillos{
    // string nombre
    // int ID_platillos : establecimiento
    // int id }

    
    
}

