//
//  ViewController.swift
//  Fireb
//
//  Created by macbook on 3/28/19.
//  Copyright © 2019 Organization. All rights reserved.
//

import UIKit
import Lottie

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        let animationView = LOTAnimationView(name: "77-im-thirsty")
        animationView.loopAnimation = true
        animationView.frame = view.frame
        self.view.addSubview(animationView)
        animationView.play()
//        animationView.frame = CGRect(x: 0, y: 0, width: 400, height: 400)
//        animationView.center = self.view.center
//        animationView.contentMode = .scaleAspectFill
//        view.addSubview(animationView)
        
        
    }


}

